import { atom } from "recoil";

export const productsState = atom({ 
    key:"productsState", 
    default: [
        {
            id: 1,
            title: "Painting",
            price: "229€",
            description: "Short description",
            image: "/assets/b.jpg", 
            category: "Sofia"
          },
          {
            id: 2,
            title: "Painting",
            price: "399€",
            description: "Short description",
            image: "/assets/c.jpg",
            category: "Mikael"
          },
          {
            id: 3,
            title: "Painting",
            price: "629€",
            description: "Short description",
            image: "/assets/d.jpg", 
            category: "Melvin"
          },
          {
            id: 4,
            title: "Painting",
            price: "399€",
            description: "Short description",
            image: "/assets/e.jpg", 
            category: "Leo"
          },
          {
            id: 5,
            title: "Painting",
            price: "199€",
            description: "Short description",
            image: "/assets/f.jpg",
            category: "Sofia"
          },
          {
            id: 6,
            title: "Painting",
            price: "320€",
            description: "Short description",
            image: "/assets/g.jpg", 
            category: "Mikael"
          },
          {
            id: 7,
            title: "Painting",
            price: "490€",
            description: "Short description",
            image: "/assets/h.jpg",
            category: "Melvin"
          },          
          {
            id: 8,
            title: "Painting",
            price: "299€",
            description: "Short description",
            image: "/assets/i.jpg",
            category: "Leo"
          },           
          {
            id: 9,
            title: "Painting",
            price: "289€",
            description: "Short description",
            image: "/assets/j.jpg", 
            category: "Sofia"
          },
          {
            id: 10,
            title: "Painting",
            price: "349€",
            description: "Short description",
            image: "/assets/k.jpg", 
            category: "Mikael"
          },
          {
            id: 11,
            title: "Painting",
            price: "550€",
            description: "Short description",
            image: "/assets/l.jpg", 
            category: "Melvin"
          },
          {
            id: 12,
            title: "Painting",
            price: "440€",
            description: "Short description",
            image: "/assets/m.jpg", 
            category: "Leo"
          },
          {
            id: 13,
            title: "Painting",
            price: "230€",
            description: "Short description",
            image: "/assets/n.jpg", 
            category: "Sofia"
          },

          {
            id: 14,
            title: "Painting",
            price: "410€",
            description: "Short description",
            image: "/assets/o.jpg", 
            category: "Mikael"
          },
          {
            id: 15,
            title: "Painting",
            price: "310€",
            description: "Short description",
            image: "/assets/p.jpg",
            category: "Melvin"
          },
          {
            id: 16,
            title: "Painting",
            price: "190€",
            description: "Short description",
            image: "/assets/q.jpg", 
            category: "Leo"
          },

          {
            id: 17,
            title: "Painting",
            price: "440€",
            description: "Short description",
            image: "/assets/r.jpg",
            category: "Sofia"
          },

          {
            id: 18,
            title: "Painting",
            price: "200€",
            description: "Short description",
            image: "/assets/s.jpg",
            category: "Melvin"
          }, 
          {
            id: 19,
            title: "Painting",
            price: "399€",
            description: "Short description",
            image: "/assets/t.jpg",
            category: "Leo"
          },
          {
            id: 20,
            title: "Painting",
            price: "230€",
            description: "Short description",
            image: "/assets/u.jpg", 
            category: "Sofia"
          },

          {
            id: 21,
            title: "Painting",
            price: "380€",
            description: "Short description",
            image: "/assets/v.jpg",
            category: "Mikael"
          },

          {
            id: 22,
            title: "Painting",
            price: "399€",
            description: "Short description",
            image: "/assets/w.jpg",
            category: "Melvin"
          }, 
          {
            id: 23,
            title: "Painting",
            price: "320€",
            description: "Short description",
            image: "/assets/x.jpg",
            category: "Leo"
          }, 
          {
            id: 24,
            title: "Painting",
            price: "299€",
            description: "Short description",
            image: "/assets/y.jpg",
            category: "Sofia"
          }, 
          {
            id: 25,
            title: "Painting",
            price: "439€",
            description: "Short description",
            image: "/assets/z.jpg",
            category: "Mikael"
          }, 
          {
            id: 26,
            title: "Painting",
            price: "239€",
            description: "Short description",
            image: "/assets/zz.jpg",
            category: "Melvin"
          }, 
          {
            id: 27,
            title: "Painting",
            price: "399€",
            description: "Short description",
            image: "/assets/zzz.jpg",
            category: "Leo"
          },
    ]
 }
 
 )