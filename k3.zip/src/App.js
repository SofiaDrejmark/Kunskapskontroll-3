import './App.css';
import { Routes, Route } from "react-router-dom"
import Header from "./components/Header";
import Home from "./pages/Home";
import Cart from './pages/Cart';
import SingleProduct from './pages/SingleProduct';
import ProductPage from './pages/ProductPage';



function App() {
  return (
    <div className="MyApp">
<Header />
    <Routes>
<Route path="/" element={<Home />}/>
<Route path="/productpage" element={<ProductPage />}/>
<Route path="/productpage/:productId" element={<SingleProduct />}/>
<Route path="/cart" element={<Cart />}/>

    </Routes>
  
    </div>
  );
}

export default App;
