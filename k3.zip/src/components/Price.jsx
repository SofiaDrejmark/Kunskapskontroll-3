import React from 'react'

function Price() {
  return (
    <div></div>
  )
}

export default Price