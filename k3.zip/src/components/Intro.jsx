import React from 'react';

function Intro() {
  return (
 <section className='intro-section'>
 
   
      <p>
      Colourful handmade paintings made out of love, with inspiration from the world around and the voice within.
       
      Creative and unique pieces to buy, for you to enjoy.
      </p>
      <a href="/productpage"> <button className='intro-btn'>
        Explore Artwork 
      </button></a>
<section className='intro-img-section'>
     <img className='introimg' src="../assets/c.jpg" alt="art" width="500px" height="400px" />
     <img className='introimg' src="../assets/s.jpg" alt="art" width="500px" height="400px" />
     
     </section>
    </section>
  )
}

export default Intro