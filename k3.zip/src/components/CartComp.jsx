import React from 'react'

import { useRecoilState } from 'recoil';
import { cartState } from "../stores/cart/atom";

function CartComp() {
const [cart, setCart] = useRecoilState(cartState)

const removeProduct = (cartProduct) => {
  let newCart = [...cart];
  newCart = newCart.filter((product) => cartProduct.id !==product.id);
  setCart(newCart)
}
  

function getProduct(ci) {
  
  return (
<div>
<ul> 
 
    <li key={ci.id}>
    <img src={ci.image} width="200px" alt="painting"/>
    <h2>{ci.title}</h2>
    <h4>{ci.price}</h4>
    <button onClick={() => removeProduct(ci)}>x</button>
    </li>
</ul>
</div>


  )
}

  return (
<div>
  <h1>My Bag</h1>
  {cart.map(getProduct)}
  <button>Proceed to Checkout</button>
</div>
  )
  }

export default CartComp 