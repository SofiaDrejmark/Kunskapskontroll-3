import React from 'react'
import { Link } from "react-router-dom"
import { useRecoilState } from 'recoil';
import { cartState } from "../stores/cart/atom";
import { useRecoilValue } from "recoil";
import { productsState } from "../stores/products/atom";

function ProductCard() {
const [cart, setCart] = useRecoilState(cartState)
const products = useRecoilValue(productsState);
  function addToCart(product) {
    const newCart = [...cart, product];
    setCart(newCart)
    console.log(newCart)
  }

  return (

<ul>

{products.map((product) => (
    <li key={product.id}>
       <img className="product-image" src={product.image} width="200px" alt="painting"/>
       <button className="addbtn" onClick={() => addToCart(product)}>Buy</button>
    <div className='product-div'><h2>{product.title}</h2>
    <h4>{product.price}</h4>
    <p>{product.description}</p>
    <Link to={`/productpage/${product.id}`}><button className="seemorebtn">See More</button></Link>
    </div>
    </li>
))}

</ul>

  )
}

export default ProductCard
