import React from "react";
import Navbar from "../partials/Navbar";


function Header() {
  return (
    <header>

      <div className="shipping-div">FREE SHIPPING WORLDWIDE</div>
        <h1>Art</h1>
        <h4>Original paintings and high quality art.</h4>
        <Navbar />
      
    </header>
  );
}

export default Header;
