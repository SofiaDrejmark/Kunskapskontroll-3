import React from "react";
import Intro from "../components/Intro";


function Home() {
  return (
    <main>
      <Intro />
    
     
      </main>
  );
}

export default Home;
