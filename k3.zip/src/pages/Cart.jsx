import React from "react"
import CartComp from '../components/CartComp';
import { cartState } from '../stores/cart/atom';
import { useRecoilValue } from "recoil";

function Cart() {
  
const products = useRecoilValue(cartState)
  return (
    <main>
      
        <CartComp products={products} />
    </main>
  )
}

export default Cart

/*
import React from 'react'

import { useRecoilState } from 'recoil';
import { cartState } from "../stores/cart/atom";
import { productsState } from "../stores/products/atom";

function Cart() {
const [cart, setCart] = useRecoilState(cartState)
const products = useRecoilState(productsState)



const removeProduct = (product) => {
  let newCart = [...cart];
  newCart = newCart.filter((product) => product.id !==product.id);
  setCart(newCart)
}
function handleRemove(id) {
  setCart(cart.filter((ci) => ci.id !== id));
}

function getProduct(ci) {
  const product = products.find((p) => p.id === ci.id);
  return (
<div>
<ul> 
 
    <li key={ci.id}>
    <img src={product.image} width="200px" alt="painting"/>
    <h2>{product.title}</h2>
    <h4>{product.price}</h4>
    <button onClick={() => handleRemove(ci.id)}>x</button>
    </li>
</ul>
</div>


  )
}

  return (
<div>
  <h1>My Bag</h1>
  {cart.map(getProduct)}
  <button>Proceed to Checkout</button>
</div>
  )
  }

export default Cart*/