import React from "react";
import { useParams } from "react-router-dom";
import {  useRecoilState, useRecoilValue } from "recoil";
import { cartState } from "../stores/cart/atom";
import { productsState } from "../stores/products/atom";


function SingleProduct() {
  const [cart, setCart] = useRecoilState(cartState)
const params = useParams(); 
const products = useRecoilValue(productsState);
const product = products.find((p) => p.id === parseInt(params.productId));


function addToCart(product) {
  const newCart = [...cart, product];
  setCart(newCart)
  console.log(newCart)
}


return (
  <div className="single-div">
    <img width="400px" src={product.image} alt={product.title} />
    <div>
      <h3>{product.title}</h3>
      <p>{product.description}</p>
      <p>{product.price}</p>
      <button className="addbtn" onClick={() => addToCart(product)}>Buy</button>
    </div>
  </div>
);
}

export default SingleProduct;
