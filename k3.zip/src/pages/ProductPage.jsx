import React from 'react'
import ProductCard from "../components/ProductCard";
import { productsState } from "../stores/products/atom";
import { useRecoilValue } from "recoil";
import { cartState } from "../stores/cart/atom";

function ProductPage() {
    const products = useRecoilValue(productsState)
  return (
    <main>
    
  <ProductCard products={products} />

    </main>
  )
}

export default ProductPage 